import random
print('''
================================================Hello and welcome to ..... Poker Ultimate, where you can play poker to your heart's content.================================================
This game is a version of five-card draw poker.
In this game you can play poker, without fear of losing real money, against a computer opponent.
To control this game you have to type in the command prompt using the keywords ".your desired action()". 
If you lose all your money you lose.
To bet money (fake of course), type deck.bet and you can choose the number of cards you want to pick up.
To save the game, type play.save() in the command prompt.
To start the game, type play.profile().
To get cards, type play.dealCard().
To fold, play.fold().
''')
class Deck: 
    def __init__(self):
        ###creating the deck
        self.hand=None
        self.deck = ['A♠', 'A♡', 'A♢', 'A♣', '2♠', '2♡', '2♢', '2♣', '3♠', '3♡', '3♢', '3♣', '4♠', '4♡', '4♢', '4♣', '5♠', '5♡', '5♢', '5♣', '6♠', '6♡', '6♢', '6♣', '7♠', '7♡', '7♢', '7♣', '8♠', '8♡', '8♢', '8♣', '9♠', '9♡', '9♢', '9♣', '10♠', '10♡', '10♢', '10♣', 'J♠', 'J♡', 'J♢', 'J♣', 'Q♠', 'Q♡', 'Q♢', 'Q♣', 'K♠', 'K♡', 'K♢', 'K♣']
    def profile(self):
        n=input("Do you have a saved file?(Y/N) ")
        if n=='N':
            prof=input("What would you like to save your profile as? ")
            name=prof + " You have $10000"
            file=open("names.txt","a")
            file.write(f"{name}\n")
            file.close
        elif n=='Y':
            prof=input("What is your profile saved as? ")
            with open("names.txt","r") as file:
                lines=file.readlines()
            for line in lines:
                if m==line[0:len(m)]:
                    print("Hello,",line.rstrip())
                    break
                else:
                    pass
        else:
            pass
        self.profile=prof #######FIGURE OUT HOW TO GET MONEY!!!
                
    def shuffle(self): 
        random.shuffle(self.deck)###shuffling the deck

        
    def dealCards(self):
        if self.hand==None:
            x=self.deck.pop()###creating the players hand
            y=self.deck.pop()
            z=self.deck.pop()
            a=self.deck.pop()
            b=self.deck.pop()
            self.hand=x+y+z+a+b

            
            x_=self.deck.pop()###creating the bots hand
            y_=self.deck.pop()
            z_=self.deck.pop()
            a_=self.deck.pop()
            b_=self.deck.pop()
            self.bot=x_+y_+z_+a_+b_
            print(self.hand)##showing the player his/her hand
        else:##preventing multiple hands
            pass


    def bet(self):###DO THIS
        pass
    def check(self):###DO THIS
        pass
    def save(self):###DO THIS
        pass
        
    


play=Deck()
play.shuffle()

        
